<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Novinky';
$_lang['security_notices'] = 'Bezpečnostní poznámky';
$_lang['welcome_messages'] = 'Vaše schránka obsahuje <strong>%d</strong> zpráv, z toho <strong>%s</strong> nepřečtených.';
$_lang['welcome_title'] = 'Vítejte v MODX správci obsahu';
$_lang['yourinfo_message'] = 'Tato část zobrazuje informace o Vás:';
$_lang['yourinfo_previous_login'] = 'Poslední přihlášení:';
$_lang['yourinfo_title'] = 'Vaše informace';
$_lang['yourinfo_total_logins'] = 'Celkový počet přihlášení:';
$_lang['yourinfo_username'] = 'Jste přihlášen jako:';