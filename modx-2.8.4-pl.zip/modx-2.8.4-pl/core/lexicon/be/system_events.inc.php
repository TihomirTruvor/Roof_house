<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Ачысціць';
$_lang['error_log'] = 'Лог памылак';
$_lang['error_log_desc'] = 'Лог памылак MODX Revolution:';
$_lang['error_log_download'] = 'Спампаваць лог памылак ([[+size]])';
$_lang['error_log_too_large'] = 'Лог памылак <em>[[+name]]</ em> занадта вялікі для прагляду. Вы можаце спампаваць лог, націснуўшы на кнопку ніжэй.';
$_lang['system_events'] = 'Сістэмныя падзеі';
$_lang['priority'] = 'Прыярытэт';