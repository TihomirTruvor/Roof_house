<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'أخبار مودكس';
$_lang['security_notices'] = 'ملاحظات الأمان';
$_lang['welcome_messages'] = 'بريدك يحتوي <strong>%d</strong> رسائل, التي <strong>%s</strong> لم تقرأ.';
$_lang['welcome_title'] = 'مرحبا بك بمدير المحتوى الخاص بك مودكس';
$_lang['yourinfo_message'] = 'هذا القسم يعرض بعض المعلومات حولك:';
$_lang['yourinfo_previous_login'] = 'آخر تسجيل دخول:';
$_lang['yourinfo_title'] = 'المعلومات الخاصة بك';
$_lang['yourinfo_total_logins'] = 'العدد الإجمالي لعمليات تسجيل الدخول:';
$_lang['yourinfo_username'] = 'قمت بتسجيل الدخول كـ:';